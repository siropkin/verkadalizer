---
name: Audit AI models/params v2
overview: Update your providers to use Gemini Flash for menu parsing and remove explicit output token caps, while fixing API schema issues and improving JSON reliability.
todos:
  - id: openai-structured-output
    content: Add OpenAI `response_format` (json_schema/json_object) and lower parsing temperature in `ai/providers/openai-provider.js` (no token cap).
    status: pending
  - id: gemini-flash-parse
    content: Switch Gemini menu parsing model to `gemini-2.5-flash` in `ai/providers/gemini-provider.js`.
    status: pending
  - id: gemini-structured-output
    content: "Add Gemini schema-based JSON output config for parsing (keep `responseMimeType: application/json`) in `ai/providers/gemini-provider.js`."
    status: pending
  - id: gemini-imageconfig-fix
    content: "Fix Gemini image generation request schema: use `generationConfig.imageConfig.aspectRatio` + `imageSize` (camelCase) in `ai/providers/gemini-provider.js`."
    status: pending
  - id: centralize-model-config
    content: Centralize per-step model IDs (parse vs image vs translate) and wire both providers to use it.
    status: pending
    dependencies:
      - openai-structured-output
      - gemini-flash-parse
      - gemini-structured-output
      - gemini-imageconfig-fix
---

# Audit and tune AI providers (models + params) — v2

## Your requested changes

- **Remove explicit output token limits** (no `maxOutputTokens` / `max_completion_tokens`).
- **Use Gemini Flash for menu parsing**: `gemini-2.5-flash`.

## What you have today (from code)

- **OpenAI**
- **Menu parsing**: `gpt-4o` via `POST /v1/chat/completions`.
- **Image generation + translation**: `gpt-image-1` via `POST /v1/images/edits`.

- **Google Gemini**
- **Menu parsing**: currently `gemini-3-pro-preview` via `:generateContent`.
- **Image generation + translation**: `gemini-3-pro-image-preview` via `:generateContent`.
- **Important bug**: your `imageConfig` keys are snake_case, but the API expects camelCase (`aspectRatio`, `imageSize`).

Key files:

- OpenAI provider: [`/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/openai-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/openai-provider.js)
- Gemini provider: [`/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/gemini-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/gemini-provider.js)

## Plan

### 1) Make menu parsing outputs reliably structured (both providers)

- **OpenAI**: add `response_format` to force JSON output (prefer `json_schema`, fallback to `json_object`), and lower parsing temperature for deterministic JSON.
- **Gemini**: keep `responseMimeType: "application/json"` and add schema-based response config where supported (e.g. `responseSchema` / `responseJsonSchema`) for stronger guarantees.
- **No explicit token caps**: we will not set `max_completion_tokens` / `maxOutputTokens`.

### 2) Switch Gemini parsing model to Flash

- Change Gemini parsing model from `gemini-3-pro-preview` to **`gemini-2.5-flash`**.

### 3) Fix Gemini image generation request schema

- Update `generationConfig.imageConfig` to use **`aspectRatio`** and **`imageSize`** (camelCase) per the API reference.
- Keep `responseModalities: ["TEXT","IMAGE"] `and ensure the response extraction continues to work with `inline_data` image parts.

### 4) Centralize model IDs per step

- Create a single shared constants/config file for per-step model IDs:
- **OpenAI parse**: `gpt-4o`
- **OpenAI image**: `gpt-image-1`
- **Gemini parse**: `gemini-2.5-flash`
- **Gemini image**: `gemini-3-pro-image-preview`

## Notes on removing token limits

- Removing explicit caps **won’t improve quality** by itself; it just allows longer outputs.
- The main risk is cost/latency spikes if a model produces unexpectedly verbose output. We’ll mitigate with **schema/JSON enforcement** and **concise output instructions**.

## Acceptance criteria

- Menu parsing returns valid JSON without truncation, with higher reliability due to `response_format` / schema enforcement.
- Gemini image generation works with the documented `imageConfig` schema.
- Model IDs are centralized and easy to update.

## Implementation todos

- `openai-structured-output`: Add OpenAI `response_format` (json_schema/json_object) and lower parsing temperature in `ai/providers/openai-provider.js`.
- `gemini-flash-parse`: Switch Gemini parsing model to `gemini-2.5-flash` in `ai/providers/gemini-provider.js`.
- `gemini-structured-output`: Add Gemini schema-based JSON output config for parsing in `ai/providers/gemini-provider.js`.
- `gemini-imageconfig-fix`: Fix Gemini image generation request: use `generationConfig.imageConfig.aspectRatio` + `imageSize`.
- `centralize-model-config`: Create shared per-step model config and wire both providers to use it.