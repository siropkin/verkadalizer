---
name: Storage review hardening
overview: Standardize storage key names, tighten persisted API-key handling, and implement a 7-day (max 30) generated-image cache using IndexedDB instead of chrome.storage.local to avoid quota issues.
todos:
  - id: inventory-and-keys
    content: Add centralized storage key constants + migration from old flat keys to new namespaced keys.
    status: completed
  - id: idb-cache-layer
    content: Implement IndexedDB helper and image cache module with TTL=7 days and LRU max=30 by lastAccessedAt.
    status: completed
    dependencies:
      - inventory-and-keys
  - id: wire-cache-messages
    content: Update background/content messaging handlers to use the new cache (save/load/cleanup) and remove chrome.storage.local base64 storage path.
    status: completed
    dependencies:
      - idb-cache-layer
  - id: api-key-hygiene
    content: "Tighten API key handling: ensure no logs/URLs leak keys; add optional Clear Keys UX and update settings load/save to new key names."
    status: completed
    dependencies:
      - inventory-and-keys
---

# Storage params + secrets + 7-day image cache

## Goals

- Make **storage param names consistent and namespaced**.
- Keep **API keys persisted** (as you selected), but follow extension best-practices: minimize exposure, avoid logging, and provide safe UX controls.
- Implement **image caching for 7 days** while keeping up to **30 generated images**, with predictable eviction and low risk of hitting `chrome.storage.local` quotas.

## Current state (what we found)

- **No `localStorage` usage**; everything is via `chrome.storage.local`.
- **Settings keys** are currently flat strings: `aiProvider`, `openaiApiKey`, `geminiApiKey`, `dietaryPreference`, `imageStyle`, `menuLanguage` (see [`popup.js`](/Users/ivan.seredkin/_projects/verkadalizer/popup.js) and [`lib/storage.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/storage.js)).
- **Generated image cache is stored as base64 data URLs in `chrome.storage.local`** under `verkadalizer_saved_images` with:
- **TTL = 3 days** (comment in `content.js` says 7 days but the code in `cleanupOldSavedImages()` uses 3 days)
- **Max 10 images**
- A **~5MB “safety” cap** that can cause early eviction and failure to retain images.

## Proposed changes

## 1) Storage key names (params)

- Introduce a single source of truth for storage keys, e.g. a new module like [`lib/storage-keys.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/storage-keys.js).
- Use a clear namespace prefix and grouping, for example:
- `vk.settings.aiProvider`
- `vk.settings.apiKeys.openai`
- `vk.settings.apiKeys.gemini`
- `vk.settings.dietaryPreference`
- `vk.settings.imageStyle`
- `vk.settings.menuLanguage`
- `vk.cache.images.meta` (small metadata only; blobs in IndexedDB)
- Add a **migration layer** so existing users keep their settings:
- On startup (background) or on popup open, detect old keys and copy into new keys once.
- Keep backward reads for one release if you want a safe rollout.

## 2) API key storage (best practices, given “persist in storage”)

Since this is a client-side extension, **persisted keys can’t be made truly secret** against a compromised browser profile or malicious extensions. Best practices here are about *reducing accidental exposure*:

- Store API keys only in `chrome.storage.local` (already the case) and never in page context.
- Ensure no logs include secrets (we’ll verify and add guardrails; today providers don’t log the key, but Gemini sends it in the URL query string, which can be exposed in network tooling).
- Prefer sending keys in **HTTP headers** where possible.
- OpenAI already uses `Authorization: Bearer ...`.
- For Gemini, the official API uses `?key=...`; we can’t always avoid that, but we can ensure we never log the full request URL and don’t include it in our own error messages.
- Add UX affordances:
- A **“Clear API keys”** button.
- Optional “mask by default” inputs (already typical for password inputs; depends on `popup.html`).

## 3) Image caching strategy (7 days, max 30), using IndexedDB

Move image bytes out of `chrome.storage.local`.

### Design

- Use **IndexedDB** for image blobs:
- DB: `verkadalizer`
- Store: `generatedImages`
- Key: `requestId`
- Value: `{ requestId, blob, mimeType, sizeBytes, createdAt, lastAccessedAt, preferenceId, styleId }`
- Keep only small metadata in `chrome.storage.local` if needed (e.g., for debugging, quick stats, or versioning), but it’s optional.

### Behavior

- On save:
- `put(requestId, blob, createdAt=now, lastAccessedAt=now)`
- Run cleanup: delete entries older than **7 days**, then enforce **max 30** by `lastAccessedAt` (LRU).
- On load:
- `get(requestId)`; if found and not expired, update `lastAccessedAt` and return `blob`.
- Convert to object URL or data URL for display in `content.js`.
- On startup / periodically:
- Run cleanup once at init (mirrors today’s `cleanupOldSavedImages()` call in `content.js`, but now it targets IndexedDB).

### Files impacted

- [`lib/storage.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/storage.js): replace `verkadalizer_saved_images` base64 map with an IndexedDB-backed cache API.
- [`background.js`](/Users/ivan.seredkin/_projects/verkadalizer/background.js): keep message actions but wire them to the new cache functions.
- [`content.js`](/Users/ivan.seredkin/_projects/verkadalizer/content.js): update restore/save/load paths to handle blob/objectURL instead of base64-in-storage.
- [`popup.js`](/Users/ivan.seredkin/_projects/verkadalizer/popup.js): migrate to new key names + optional “clear keys” UX.
- Add new helper(s):
- [`lib/idb.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/idb.js) (minimal IndexedDB wrapper)
- [`lib/image-cache.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/image-cache.js) (TTL/LRU policy, 7 days + max 30)
- [`lib/storage-keys.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/storage-keys.js) (centralized names)

## Validation plan (no server required)

- Manual flows:
- Save settings, reload extension, confirm settings persist.
- Generate an image, reload the menu page, confirm it restores from cache.
- Generate >30 images, confirm oldest-by-access gets evicted.
- Simulate time-based eviction by temporarily setting TTL to a small value during dev (optional) and confirming cleanup.

## Notes / constraints

- `chrome.storage.local` is great for **small settings**, not bulk base64 images. IndexedDB is the right fit for week-long retention.
- Persisted API keys in an extension are “best-effort privacy”, not “secrets management” like a backend vault.