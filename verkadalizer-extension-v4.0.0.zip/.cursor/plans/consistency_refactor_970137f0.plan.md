---
name: Consistency refactor
overview: Make the data-flow contracts (actions/progress/settings) consistent across popup/content/background, and standardize AI provider structure via a shared provider interface + shared utilities—without behavior changes or adding a build step.
todos:
  - id: centralize-actions
    content: Create `lib/messages/actions.js` and switch `background.js` + `popup.js` to use it (convert popup to module via `popup.html`).
    status: completed
  - id: progress-consistency
    content: Reduce duplicated progress-step enums in `content.js` while preserving the same UI mapping and fallback behavior.
    status: completed
  - id: provider-registry
    content: Refactor `ai/providers/ai-providers.js` into a single provider map with consistent {meta, parseMenu, generateImage, translateMenuImage} interface.
    status: completed
  - id: provider-utils
    content: Create shared `ai/providers/provider-utils.js` and update OpenAI/Gemini providers to reuse JSON extraction + error parsing helpers.
    status: completed
  - id: jsdoc-contracts
    content: Add JSDoc typedefs and align naming across the pipeline and provider layer for consistent data flow documentation.
    status: completed
  - id: docs-refresh
    content: Update `ARCHITECTURE.md` (and other knowledge-base docs like `README.md` if needed) to reflect the final data-flow contracts, provider registry shape, and file layout after refactor.
    status: completed
---

# Verkadalizer data-flow consistency refactor (no-build, refactor-only)

## Goals

- **Consistency**: one clear “contract” for message actions, progress steps, and provider interfaces.
- **Simplification**: reduce duplicated logic (JSON extraction, fetch error parsing, provider registry wiring).
- **Best-practice organization (within constraints)**: keep MV3 entrypoints at repo root, but factor shared logic into small, well-named modules.
- **No behavior changes**: identical UI/UX and network behavior.

## Current end-to-end data flow (as-is)

```mermaid
sequenceDiagram
participant Popup as popup.js
participant Content as content.js
participant BG as background.js
participant Providers as ai/providers/*
participant Storage as chrome.storage.local

Popup->>Storage: set aiProvider/openaiApiKey/geminiApiKey
Content->>BG: sendMessage({action: PROCESS_IMAGE, imageUrl, requestId})
BG->>Storage: loadSettings() and get dietaryPreference/imageStyle/menuLanguage
BG->>Providers: parseMenuWithAI(updateProgress)
Providers-->>BG: updateProgress(step, extra)
BG-->>Content: GET_PROGRESS returns {step, extra}
BG->>Providers: generateImageWithAI(...) (and translateMenuImageWithAI in parallel)
BG->>BG: mergeMenuLayerWithBackground(...)
BG-->>Content: PROCESS_IMAGE response {success, b64}
Content->>Storage: saveGeneratedImage(requestId, dataUrl)
```

## Key inconsistencies / opportunities

- **Duplicated contracts**:
  - `ACTIONS` are duplicated in [`background.js`](/Users/ivan.seredkin/_projects/verkadalizer/background.js), [`content.js`](/Users/ivan.seredkin/_projects/verkadalizer/content.js), and `popup.js` uses raw string literals.
  - `PROGRESS_STEPS` is canonical in [`ai/providers/progress-steps.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/progress-steps.js), but `content.js` maintains a separate inline copy.
- **Provider wiring duplication**: [`ai/providers/ai-providers.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/ai-providers.js) maintains 3 parallel maps (parse/generate/translate) that must stay in sync.
- **Provider implementation duplication**: OpenAI/Gemini share logic patterns (fetch+decode errors, “JSON inside markdown fence” parsing, logging) that can be centralized.
- **Presentation mapping duplication**: [`lib/progress-steps.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/progress-steps.js) mirrors the UI mapping logic embedded in `content.js`.

## Target structure (best-practice, no build step)

- Keep entrypoints at root: `background.js`, `content.js`, `popup.html`, `popup.js`, `manifest.json`.
- Introduce small ESM “shared contract” modules used by background + popup:
  - `lib/messages/actions.js` (canonical message action strings)
  - `lib/messages/protocol.js` (JSDoc typedefs + validation helpers for message shapes)
- Make `popup.js` an ES module (via `popup.html`) so it can import the shared contracts.
- Keep `content.js` as a single file (per Chrome limitations) but reduce drift risk by:
  - removing its separate `PROGRESS_STEPS` enum and using **string step IDs** in mapping keys (or alternatively, keeping the enum but adding a **runtime validation warning** when BG returns an unknown step).

## Implementation plan

### 1) Centralize message action names (popup + background)

- Add [`lib/messages/actions.js`](/Users/ivan.seredkin/_projects/verkadalizer/lib/messages/actions.js) exporting an `ACTIONS` object.
- Update [`background.js`](/Users/ivan.seredkin/_projects/verkadalizer/background.js) to import and use `ACTIONS` instead of defining its own.
- Convert `popup.js` to ESM and import `ACTIONS`:
  - Update [`popup.html`](/Users/ivan.seredkin/_projects/verkadalizer/popup.html) script tag to `type="module"`.
  - Update [`popup.js`](/Users/ivan.seredkin/_projects/verkadalizer/popup.js) to use `ACTIONS.*` instead of string literals.

### 2) Make progress-step handling consistent (providers + background + content)

- Keep **canonical** progress IDs in [`ai/providers/progress-steps.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/progress-steps.js).
- Ensure [`background.js`](/Users/ivan.seredkin/_projects/verkadalizer/background.js) is the single owner of “progress storage shape” (`{step, extra, timestamp}`) and that all provider calls update via one wrapper.
- Update [`content.js`](/Users/ivan.seredkin/_projects/verkadalizer/content.js) to **remove duplicated enums** where possible:
  - Prefer `STEP_CONFIG` keyed by literal step strings (same IDs as providers), and keep `stepToProgressData` logic unchanged.
  - Keep “unknown step” fallback behavior.

### 3) Normalize provider registry structure

- Refactor [`ai/providers/ai-providers.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/ai-providers.js) to a single `PROVIDERS` map:
  - `PROVIDERS[type] = { meta, parseMenu, generateImage, translateMenuImage }`
  - `getProvider(type)` returns the object with a default fallback.
  - `parseMenuWithAI` / `generateImageWithAI` / `translateMenuImageWithAI` become thin wrappers around `getProvider(type)`.

### 4) Deduplicate shared provider logic (without changing behavior)

- Add `ai/providers/provider-utils.js` for shared helpers:
  - `parseJsonFromModelText(text)` (handles fenced JSON + raw JSON)
  - `readErrorMessage(response)` (best-effort JSON error parsing)
  - small logging helpers (optional; keep existing log strings intact to preserve debugging familiarity).
- Update [`ai/providers/openai-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/openai-provider.js) and [`ai/providers/gemini-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/gemini-provider.js) to use the shared helpers.

### 5) Consistent naming + JSDoc contracts

- Add/align JSDoc typedefs for:
  - `ParsedMenuData`, `ProgressUpdate`, `ProviderType`, `ProcessImageResult`
- Ensure function names follow consistent verb+noun patterns:
  - `parseMenu...`, `generateMenuImage...`, `translateMenuImage...`, `processImageRequest` (or `processMenuImageRequest` if rename is purely internal).

## Non-goals (explicit)

- No bundler/build tooling.
- No UI/UX changes.
- No changes to API models, chosen OpenAI/Gemini models, image sizes, or timeouts.

## Files expected to change

- Entry points: [`background.js`](/Users/ivan.seredkin/_projects/verkadalizer/background.js), [`content.js`](/Users/ivan.seredkin/_projects/verkadalizer/content.js), [`popup.js`](/Users/ivan.seredkin/_projects/verkadalizer/popup.js), [`popup.html`](/Users/ivan.seredkin/_projects/verkadalizer/popup.html)
- Provider layer: [`ai/providers/ai-providers.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/ai-providers.js), [`ai/providers/openai-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/openai-provider.js), [`ai/providers/gemini-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/gemini-provider.js)
- New shared modules: `lib/messages/actions.js`, `lib/messages/protocol.js`, `ai/providers/provider-utils.js`

## Validation (manual)

- Confirm popup loads and saves settings correctly (provider switch toggles the right key field).
- Confirm content script:
  - buttons appear,
  - generate/cancel works,
  - progress spinner updates,
  - cached restore still works.
- Confirm both providers still function (no request body changes).

## Documentation updates (required)

- Update [`ARCHITECTURE.md`](/Users/ivan.seredkin/_projects/verkadalizer/ARCHITECTURE.md) to reflect:\n  - canonical locations of `ACTIONS` / progress steps\n  - the finalized provider registry shape (`PROVIDERS` map) and shared provider utils\n  - any renamed/re-homed modules and new contracts/typedefs\n+- If the public-facing behavior/usage instructions are impacted by file layout changes (even if behavior is identical), also update:\n  - [`README.md`](/Users/ivan.seredkin/_projects/verkadalizer/README.md)\n  - any other referenced “knowledge base” docs in the repo