---
name: Parse-integrated translation
overview: Integrate language detection + translation into the parse stage, feed translated text into prompts, and skip translation-image generation when the menu is already in the target language.
todos:
  - id: prompt-schema
    content: Extend `buildMenuParsingPrompt()` to request detected language + full-text translation outputs while preserving existing fields.
    status: completed
  - id: thread-params
    content: Plumb `translationLanguage` through `parseMenuWithAI()` and both provider parse implementations.
    status: completed
  - id: skip-translation
    content: In `background.js`, skip `translateMenuImageWithAI()` when detected language matches target (primary-language match).
    status: completed
    dependencies:
      - thread-params
      - prompt-schema
  - id: use-translated-dishes
    content: Update `buildMenuFoodGenerationPrompt()` to use `translatedName`/`translatedDescription` when translation is enabled.
    status: completed
    dependencies:
      - prompt-schema
  - id: translation-prompt-glossary
    content: Optionally enrich `buildMenuTranslationPrompt()` with parse-provided translated text/glossary to reduce hallucinations.
    status: completed
    dependencies:
      - prompt-schema
---

# Parse-integrated menu translation (skip when same language)

## Goals

- **Extend menu parsing (Stage 1)** so the parse model also:
  - **detects the menu language**
  - **translates all visible menu text** when translation is enabled
  - produces a **translation glossary / translated fields** that downstream stages can reuse
- **Keep food image generation prompt in original dish names** (Stage 2 uses original `name` / `visualAppeal` for best image-model results; translated fields are used for the text overlay/translation layer guidance).
- **Skip Stage 2 translation-image generation** when parse detects the menu language already matches the chosen translation language (primary-language match, e.g. `en` == `en_US`).
- Keep your current output architecture: **food background + (optional) translated menu layer + merge**.

## Current flow (today)

```mermaid
flowchart TD
  bg[background.js]
  parse[parseMenuWithAI]
  food[generateImageWithAI]
  translate[translateMenuImageWithAI]
  merge[mergeMenuLayerWithBackground]

  bg --> parse
  bg --> food
  bg --> translate
  food --> merge
  translate --> merge
```

## Target flow (after change)

```mermaid
flowchart TD
  bg[background.js]
  parse[parseMenuWithAI_parsePlusTranslate]
  food[generateImageWithAI_foodPromptUsesOriginalText]
  translate[translateMenuImageWithAI_skipIfSameLanguage]
  merge[mergeMenuLayerWithBackground]

  bg --> parse
  parse -->|detectedLanguage,(optional) translatedName/translatedDescription| bg
  bg --> food
  bg --> translate
  food --> merge
  translate --> merge
```

## Implementation plan

- Update Stage 1 prompt + schema
  - Extend `buildMenuParsingPrompt()` in [`/Users/ivan.seredkin/_projects/verkadalizer/ai/prompts.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/prompts.js) to accept `translationLanguage` and include:
    - `detectedLanguage` (BCP-47-ish primary tag like `en`, `fr`, `ja`)
    - per-item `translatedName` / `translatedDescription` when translation is enabled (and keep existing `name`, `description`, `selectedItems` unchanged for backward compatibility)

- Thread translation choice into provider parse calls
  - Update [`/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/ai-providers.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/ai-providers.js) so `parseMenuWithAI()` accepts `translationLanguage` and passes it through.
  - Update provider implementations:
    - [`/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/openai-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/openai-provider.js)
    - [`/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/gemini-provider.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/providers/gemini-provider.js)

to call the updated `buildMenuParsingPrompt(preference, translationLanguage)`.

- Use translated text in the food/background prompt
  - **Decision**: Do **NOT** use translated dish names/descriptions for the food/background generation prompt. Always use the original dish names (`name`) because image models tend to produce better results with English/original dish names. Use parse-provided translations to guide the **text overlay / translation layer** instead (see next bullet).

- Improve translation-image prompt using parse output (optional but aligned)
  - Update [`/Users/ivan.seredkin/_projects/verkadalizer/ai/prompts/menu-translation.js`](/Users/ivan.seredkin/_projects/verkadalizer/ai/prompts/menu-translation.js) to optionally accept `parsedMenuData` and embed a **reference glossary** derived from parse-provided translations, telling the image model to prefer these translations and not invent text.

- Skip translation image generation when languages match
  - Update [`/Users/ivan.seredkin/_projects/verkadalizer/background.js`](/Users/ivan.seredkin/_projects/verkadalizer/background.js) to:
    - pass `menuLanguage` into `parseMenuWithAI({ ..., translationLanguage: menuLanguage })`
    - after parsing, compute `isTranslationEnabled` using primary-language match between `parsedMenuData.detectedLanguage` and the requested target language
    - if languages match, set `isTranslationEnabled = false` so `translationPromise` becomes `Promise.resolve(null)` (and merged layer uses original `imageUrl`).

## Notes / constraints

- This plan keeps your **existing compositing approach** (which is best for crisp readable text) and only adds parse-driven language detection/translation + a guard to avoid unnecessary translation-image generation.
- Language equality will be **primary-language match** (e.g., `en` matches `en_US`; `pt` matches `pt_BR` if you add it later).

## Implementation todos

- `prompt-schema`: Extend parse prompt JSON schema to include detected language + translated text outputs
- `thread-params`: Plumb `translationLanguage` through `parseMenuWithAI` → provider parse functions
- `skip-translation`: Gate `translateMenuImageWithAI` call in `background.js` using parse `detectedLanguage`
- `use-translated-dishes`: (Decision: cancelled) Keep original dish names in food generation prompt; use parse translations to guide the translation/text overlay stage instead.
- `translation-prompt-glossary`: Add optional reference translations into `buildMenuTranslationPrompt()`